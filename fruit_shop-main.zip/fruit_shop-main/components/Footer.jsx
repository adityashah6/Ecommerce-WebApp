import React from "react";

const Footer = () => {
    return (
        <div className="footer-container">
            <p>2022 Fruit Shop All Rights Reserved.</p>
            <p className="icons">
            </p>
        </div>
    )
}

export default Footer;