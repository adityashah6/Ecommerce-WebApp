npm install --legacy-peer-deps
npm install -g @sanity/cli
cd sanity_fruitshop
sanity install
sanity manage
echo '\nEnter in your login information using Github\n'